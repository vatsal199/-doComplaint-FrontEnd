import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainboard',
  templateUrl: './mainboard.component.html',
  styleUrls: ['./mainboard.component.css']
})
export class MainboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
